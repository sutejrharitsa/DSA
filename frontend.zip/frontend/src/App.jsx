import React, { useState, useEffect } from 'react';
import axios from 'axios';
import NotificationPanel from './components/NotificationPanel';
import ContextPanel from './components/ContextPanel';
import AddModal from './components/AddModal';

const API_URL = 'http://localhost:8000';

function App() {
  const [activeQueue, setActiveQueue] = useState([]);
  const [dndBuffer, setDndBuffer] = useState([]);
  const [isDND, setIsDND] = useState(false);
  const [globalSummary, setGlobalSummary] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modeName, setModeName] = useState("Normal");

  // New Stats State
  const [stats, setStats] = useState({ queueSize: 0, burstCount: 0 });

  // Poll Backend
  const fetchState = async () => {
    try {
      const res = await axios.get(`${API_URL}/list`);
      setActiveQueue(res.data.active_queue);
      setDndBuffer(res.data.dnd_buffer);
      setIsDND(res.data.is_dnd);
      setModeName(res.data.mode);
      setGlobalSummary(res.data.global_summary);

      // Calculate Stats
      const burstItems = res.data.active_queue.filter(n => n.content.includes("[BURST]")).length;
      setStats({
        queueSize: res.data.active_queue.length + res.data.dnd_buffer.length,
        burstCount: burstItems
      });

    } catch (err) {
      console.error("API Error", err);
    }
  };

  useEffect(() => {
    fetchState();
    const interval = setInterval(fetchState, 2000);
    return () => clearInterval(interval);
  }, []);

  const handleAdd = async (data) => {
    try {
      const res = await axios.post(`${API_URL}/notify`, data);
      setActiveQueue(res.data.system_state.active_queue);
      setDndBuffer(res.data.system_state.dnd_buffer);
    } catch (err) { console.error(err); }
  };

  const toggleDND = async () => {
    try {
      await axios.post(`${API_URL}/config/mode`, {
        active: !isDND,
        mode_name: !isDND ? "Focus" : "Normal"
      });
      fetchState();
    } catch (err) { console.error(err); }
  };

  const handleUndo = async () => {
    try {
      const res = await axios.post(`${API_URL}/undo`);
      if (res.data.system_state) {
        fetchState(); // Refresh full state
      }
    } catch (err) { console.error("Undo failed", err); }
  };

  const handleDismiss = async (id) => {
    // Optimistic
    setActiveQueue(prev => prev.filter(n => n.id !== id));
    try {
      await axios.delete(`${API_URL}/notification/${id}`);
    } catch (err) { fetchState(); }
  };

  return (
    <>
      <div className="desktop-background"></div>

      <div className="main-grid">
        {/* Left Column: Context */}
        <ContextPanel
          isDND={isDND}
          toggleDND={toggleDND}
          stats={stats}
          modeName={modeName}
        />

        {/* Center Column: Hero Notification Panel */}
        <div className="hero-column">
          <NotificationPanel
            activeQueue={activeQueue}
            dndBuffer={dndBuffer}
            isDND={isDND}
            globalSummary={globalSummary}
            onDismiss={handleDismiss}
            onAddClick={() => setIsModalOpen(true)}
            onUndo={handleUndo}
          />
        </div>

        {/* Right Column: Balance / Empty for now (or future widgets) */}
        <div className="side-column">
          {/* Keeping it empty to emphasize the 'floating' hero in the center-right */}
        </div>
      </div>

      <AddModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSubmit={handleAdd}
      />
    </>
  );
}

export default App;
