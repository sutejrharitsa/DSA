import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send, ChevronDown } from 'lucide-react';

const AddModal = ({ isOpen, onClose, onSubmit }) => {
    const [content, setContent] = useState('');
    const [appType, setAppType] = useState('work');
    const [sender, setSender] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!content) return;
        onSubmit({ content, app_type: appType, sender: sender || 'Unknown' });
        setContent('');
        setSender('');
        onClose();
    };

    return (
        <AnimatePresence>
            {isOpen && (
                <>
                    {/* Backdrop */}
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        onClick={onClose}
                        className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40"
                    />

                    {/* System Sheet / Pill */}
                    <motion.div
                        initial={{ y: "100%", opacity: 0 }}
                        animate={{ y: 0, opacity: 1, transition: { type: "spring", damping: 25, stiffness: 300 } }}
                        exit={{ y: "100%", opacity: 0 }}
                        className="fixed bottom-8 left-1/2 transform -translate-x-1/2 w-[480px] bg-[#1c1c1e] text-white rounded-[24px] shadow-2xl border border-white/10 z-50 overflow-hidden"
                    >
                        <div className="p-4">
                            {/* Header */}
                            <div className="flex justify-between items-center mb-4 px-2">
                                <span className="text-sm font-semibold text-gray-400">New Notification</span>
                                <button onClick={onClose} className="p-1 hover:bg-white/10 rounded-full transition-colors">
                                    <ChevronDown size={20} className="text-gray-400" />
                                </button>
                            </div>

                            <form onSubmit={handleSubmit} className="space-y-3">
                                {/* Input Row 1: Sender & App */}
                                <div className="flex gap-2">
                                    <input
                                        type="text"
                                        placeholder="Sender (e.g., Mom)"
                                        value={sender}
                                        onChange={e => setSender(e.target.value)}
                                        className="flex-1 bg-white/10 border-none rounded-xl px-4 py-3 text-sm focus:ring-0 placeholder-gray-500 font-medium text-white"
                                    />
                                    <select
                                        value={appType}
                                        onChange={e => setAppType(e.target.value)}
                                        className="bg-white/10 border-none rounded-xl px-4 py-3 text-sm text-gray-300 focus:ring-0 appearance-none cursor-pointer hover:bg-white/15 transition-colors font-medium"
                                    >
                                        <option value="work">Work</option>
                                        <option value="social">Social</option>
                                        <option value="news">News</option>
                                        <option value="calendar">Calendar</option>
                                        <option value="finance">Finance</option>
                                        <option value="emergency">Emergency</option>
                                    </select>
                                </div>

                                {/* Input Row 2: Content */}
                                <div className="relative">
                                    <textarea
                                        placeholder="Message content..."
                                        value={content}
                                        onChange={e => setContent(e.target.value)}
                                        className="w-full bg-white/10 border-none rounded-xl px-4 py-3 text-sm h-24 resize-none focus:ring-0 placeholder-gray-500 text-white leading-relaxed"
                                        onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) handleSubmit(e) }}
                                    />
                                    <button
                                        type="submit"
                                        className="absolute bottom-3 right-3 p-2 bg-blue-500 rounded-full hover:bg-blue-400 transition-colors shadow-lg shadow-blue-500/20"
                                    >
                                        <Send size={16} />
                                    </button>
                                </div>
                            </form>
                        </div>
                    </motion.div>
                </>
            )}
        </AnimatePresence>
    );
};

export default AddModal;
