import React from 'react';
import { Moon, Sun, BarChart2, Clock, Zap } from 'lucide-react';

const ContextPanel = ({ isDND, toggleDND, stats, modeName }) => {
    return (
        <div className="side-column">
            {/* Focus Mode Card */}
            <div
                className="glass-card p-6 cursor-pointer"
                onClick={toggleDND}
                style={{ borderColor: isDND ? 'var(--accent-indigo)' : 'rgba(255,255,255,0.1)' }}
            >
                <div className="flex items-center gap-3 mb-2">
                    {isDND ? <Moon className="text-indigo-400" size={20} /> : <Sun className="text-yellow-400" size={20} />}
                    <span className="text-xs font-semibold uppercase tracking-wider text-secondary">Focus Status</span>
                </div>
                <h2 className="text-2xl font-bold mb-1">{modeName}</h2>
                <p className="text-sm text-tertiary">
                    {isDND ? "Notifications silenced." : "All notifications delivered."}
                </p>
            </div>

            {/* Quick Stats Card */}
            <div className="glass-card p-6">
                <div className="flex items-center gap-3 mb-4">
                    <BarChart2 className="text-green-400" size={20} />
                    <span className="text-xs font-semibold uppercase tracking-wider text-secondary">System Load</span>
                </div>

                <div className="space-y-4">
                    <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                            <Clock size={16} className="text-tertiary" />
                            <span className="text-sm">Queue Size</span>
                        </div>
                        <span className="font-mono">{stats.queueSize}</span>
                    </div>
                    <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                            <Zap size={16} className="text-tertiary" />
                            <span className="text-sm">Burst Detected</span>
                        </div>
                        <span className="font-mono text-orange-400">{stats.burstCount > 0 ? "YES" : "NO"}</span>
                    </div>
                </div>
            </div>

            <div className="text-xs text-tertiary text-center mt-4 opacity-50">
                Demo Mode v1.2 • 16:10 Aspect Ratio
            </div>
        </div>
    );
};

export default ContextPanel; 
