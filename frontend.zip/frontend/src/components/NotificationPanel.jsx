import React from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Bell, Moon, Plus, RotateCcw } from 'lucide-react';
import NotificationItem from './NotificationItem';

const NotificationPanel = ({
    activeQueue,
    dndBuffer,
    isDND,
    globalSummary,
    onDismiss,
    onAddClick,
    onUndo
}) => {
    return (
        <div className="w-[520px] h-[85vh] flex flex-col relative transition-all duration-500 ease-spring">
            {/* Header / Date - Removed for cleaner "Floating" look, relies on Context Panel for clock */}


            {/* Main Glass Container */}
            <div className="glass-panel flex-1 overflow-hidden flex flex-col relative">
                <div className="flex-1 overflow-y-auto p-4 content-area">
                    <AnimatePresence>
                        {/* Summary Card */}
                        {(globalSummary && (isDND || globalSummary.summary)) && (
                            <motion.div
                                initial={{ opacity: 0, scale: 0.95 }}
                                animate={{ opacity: 1, scale: 1 }}
                                exit={{ opacity: 0, scale: 0.95 }}
                                className="mb-4 bg-white/5 border border-white/10 rounded-2xl p-4"
                            >
                                <div className="flex items-center gap-2 mb-2 text-secondary">
                                    {isDND ? <Moon size={14} /> : <Bell size={14} />}
                                    <span className="text-xs font-bold uppercase tracking-wider">Summary</span>
                                </div>
                                {globalSummary.summary ? (
                                    globalSummary.summary.map((line, idx) => (
                                        <p key={idx} className="text-sm text-primary mb-1 pl-4 border-l-2 border-white/20">{line}</p>
                                    ))
                                ) : (
                                    <p className="text-sm text-primary">{globalSummary.message}</p>
                                )}
                            </motion.div>
                        )}

                        {/* Notifications */}
                        {activeQueue.map(n => (
                            <NotificationItem
                                key={n.id}
                                data={n}
                                onDismiss={onDismiss}
                            />
                        ))}
                    </AnimatePresence>

                    {activeQueue.length === 0 && (!isDND || dndBuffer.length === 0) && (
                        <div className="h-full flex items-center justify-center text-tertiary">
                            <p>No Notifications</p>
                        </div>
                    )}
                </div>

                {/* Bottom Action Bar (Floating inside glass) */}
                <div className="p-4 border-t border-white/5 bg-black/20 backdrop-blur-md flex justify-between items-center">
                    <button
                        onClick={onUndo}
                        className="p-3 rounded-full hover:bg-white/10 text-orange-400 transition-colors"
                        title="Undo"
                    >
                        <RotateCcw size={20} />
                    </button>

                    <span className="text-xs text-secondary font-medium uppercase tracking-widest">
                        {activeQueue.length} Active
                    </span>

                    <button
                        onClick={onAddClick}
                        className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white hover:bg-blue-400 transition-all shadow-lg hover:shadow-blue-500/30"
                    >
                        <Plus size={24} />
                    </button>
                </div>
            </div>
        </div>
    );
};

export default NotificationPanel;
