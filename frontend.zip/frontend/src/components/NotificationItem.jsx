import React from 'react';
import { motion, useAnimation } from 'framer-motion';
import { MessageSquare, Briefcase, AlertTriangle, Hash, Heart, DollarSign, Calendar, Bell } from 'lucide-react';

const APP_ICONS = {
    social: MessageSquare,
    work: Briefcase,
    emergency: AlertTriangle,
    news: Hash,
    health: Heart,
    finance: DollarSign,
    calendar: Calendar,
    default: Bell
};

const NotificationItem = ({ data, onDismiss, isBuffered = false }) => {
    const controls = useAnimation();
    const Icon = APP_ICONS[data.app_type] || APP_ICONS.default;

    const handleDragEnd = async (event, info) => {
        const offset = info.offset.x;
        if (Math.abs(offset) > 100) {
            await controls.start({ x: offset > 0 ? 500 : -500, opacity: 0 });
            onDismiss(data.id);
        } else {
            controls.start({ x: 0, opacity: 1 });
        }
    };

    // Helper: Relative Time (e.g., "2m ago")
    const getRelativeTime = (timestamp) => {
        const diff = Math.floor(Date.now() / 1000) - timestamp;
        if (diff < 60) return 'Now';
        if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
        return `${Math.floor(diff / 3600)}h ago`;
    };

    return (
        <motion.div
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            controls={controls}
            onDragEnd={handleDragEnd}
            layout
            initial={{ opacity: 0, y: 15, scale: 0.96 }}
            animate={{
                opacity: isBuffered ? 0.6 : 1,
                y: 0,
                scale: 1,
                transition: { type: "spring", stiffness: 450, damping: 28 }
            }}
            exit={{
                opacity: 0,
                scale: 0.9,
                transition: { duration: 0.2 }
            }}
            whileHover={{ scale: 1.01 }}
            className={`glass-card mb-3 relative group overflow-hidden select-none cursor-grab active:cursor-grabbing backdrop-blur-xl`}
            style={{
                touchAction: 'none',
                minHeight: '80px', // Standard height
                padding: '12px 14px' // Standard macOS padding
            }}
        >
            {/* Row 1: Icon | App Name | Time */}
            <div className="flex items-center gap-2.5 mb-2">
                {/* Squircle Icon */}
                <div className="w-[26px] h-[26px] bg-white rounded-[6px] flex items-center justify-center shadow-sm">
                    {/* Icon color matches system accent often, simplified here */}
                    <Icon size={16} className="text-black" strokeWidth={2.5} />
                </div>

                {/* App Name */}
                <span className="text-[13px] font-medium text-white/90 tracking-wide uppercase opacity-90">
                    {data.app_type}
                </span>

                {/* Time (Auto Pushed Right) */}
                <span className="ml-auto text-[12px] font-normal text-white/50">
                    {getRelativeTime(data.timestamp)}
                </span>
            </div>

            {/* Row 2: Content Body */}
            <div className="pl-0">
                {/* Sender is Title */}
                <h3 className="text-[15px] font-semibold text-white leading-tight mb-0.5">
                    {data.sender}
                </h3>
                {/* Message Body */}
                <p className="text-[14px] text-white/85 leading-snug line-clamp-3">
                    {data.content}
                </p>
            </div>

            {/* Summary Indicator (Light Blue Highlight for AI) */}
            {data.summary && data.summary !== "Notification not found." && (
                <div className="mt-2.5 bg-blue-500/10 border border-blue-500/20 rounded-lg px-2.5 py-1.5 backdrop-blur-md">
                    <p className="text-[11px] font-semibold text-blue-300">
                        AI Summary: <span className="text-blue-100 font-normal">{data.summary}</span>
                    </p>
                </div>
            )}
        </motion.div>
    );
};

export default NotificationItem;
